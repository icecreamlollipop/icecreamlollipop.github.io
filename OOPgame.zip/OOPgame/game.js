class Game {
    reset(){

    }
    win(){

    }
    lose(){

    }
}

class Grid{
    constructor(squares){
        this.squares = squares;
    }
    move(){

    }
    generateSquare(){
        // TODO
    }
}

class Square{
    constructor(number) {
        this.number = number;
    }
    draw(element){
        
    }
}
